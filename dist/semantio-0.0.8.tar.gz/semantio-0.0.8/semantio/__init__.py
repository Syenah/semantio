import warnings

# Suppress all warnings globally
warnings.simplefilter("ignore")
